select d.nombre_marca, c.nombre_modelo , e.nombre_grupo, a.fecha_compra , a.matricula , b.nombre_color ,a.kilometros, f.nombre_aseguradora, ha.numero_poliza 
from modeladoflota.coches a inner join modeladoflota.colores b on a.id_color = b.id_color
inner join modeladoflota.modelos c on a.id_modelo = c.id_modelo
inner join modeladoflota.marcas d on c.id_marca = d.id_marca 
inner join modeladoflota.grupos e on d.id_grupo = e.id_grupo 
inner join modeladoflota.hist_aseguradoras ha on a.id_coche = ha.id_coche 
inner join modeladoflota.aseguradoras f on ha.id_aseguradora = f.id_aseguradora
where a.fecha_baja = '4000-01-01'
;

