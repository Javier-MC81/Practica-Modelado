--- Modelo coches normalizado

create schema modeladoflota authorization hjjfwevk;

-- 1. Creo la tabla de grupos empresariales


create table modeladoflota.grupos(
	id_grupo varchar(20) not null, --PK, FK
	nombre_grupo varchar(200) not  null

);
--PK

alter table modeladoflota.grupos
add constraint id_grupo_PK primary key (id_grupo);

--- 2. Creo la tabla de marcas

create table modeladoflota.marcas(
	id_marca varchar(20) not null, --PK, FK
	nombre_marca varchar(200) not  null,
	id_grupo varchar(20) not null -- FK
);

--PK
alter table modeladoflota.marcas
add constraint id_marca_PK primary key (id_marca);

-- FK

alter table modeladoflota.marcas
add constraint marcas_grupos_FK foreign key (id_grupo)
references modeladoflota.grupos(id_grupo);


-- 3. Creo la tabla de modelos

create table modeladoflota.modelos(
	id_modelo varchar(20) not null, --PK, FK
	nombre_modelo varchar(200) not null,
	id_marca varchar(20) not null -- FK
);

--PK
alter table modeladoflota.modelos
add constraint id_modelo_PK primary key (id_modelo);

-- FK

alter table modeladoflota.modelos
add constraint modelos_marcas_FK foreign key (id_marca)
references modeladoflota.marcas(id_marca);

-- 3. Creo la tabla de colores

create table modeladoflota.colores(
	id_color varchar(20) not null, --PK, FK
	nombre_color varchar(200) not null
	
);

--PK
alter table modeladoflota.colores
add constraint id_color_PK primary key (id_color);

-- Cargamos los datos de los grupos empresariales

insert into modeladoflota.grupos (id_grupo, nombre_grupo) values ('01','Toyota Motor');
insert into modeladoflota.grupos (id_grupo, nombre_grupo) values ('02','Grupo Volkswagen');
insert into modeladoflota.grupos (id_grupo, nombre_grupo) values ('03','Grupo Stellantis');
insert into modeladoflota.grupos (id_grupo, nombre_grupo) values ('04','Grupo BMW');


-- Cargamos los datos de las marcas

insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('01','Toyota','01');
insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('02','Lexus','01');
insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('03','Mazda','01');

insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('04','Audi','02');
insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('05','Seat','02');
insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('06','Skoda','02');

insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('07','Fiat','03');
insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('08','Peugeot','03');
insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('09','Opel','03');

insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('10','BMW','04');
insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('11','Mini','04');
insert into modeladoflota.marcas (id_marca, nombre_marca, id_grupo) values ('12','Rolls-Royce','04');


-- Cargamos los datos de los modelos

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('01','Corolla','01');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('02','Yaris','01');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('03','Rav4','01');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('04','RX','02');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('05','NX','02');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('06','ES','02');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('07','CX-60','03');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('08','MX-30','03');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('09','CX-5','03');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('10','A1','04');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('11','A3','04');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('12','A5','04');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('13','León','05');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('14','Ibiza','05');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('15','Ateca','05');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('16','Octavia','06');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('17','Kodiaq','06');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('18','Superb','06');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('19','500','07');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('20','Tipo','07');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('21','Panda','07');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('22','208','08');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('23','2008','08');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('24','3008','08');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('25','Astra','09');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('26','Corsa','09');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('27','Mokka','09');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('28','i3','10');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('29','i4','10');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('30','i7','10');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('31','Countryman','11');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('32','Coupé','11');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('33','Roadster','11');

insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('34','Cullinan','12');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('35','Dawn','12');
insert into modeladoflota.modelos  (id_modelo, nombre_modelo , id_marca) values ('36','Ghost','12');

-- Cargamos los datos de los colores

insert into modeladoflota.colores  (id_color, nombre_color) values ('01','Negro');
insert into modeladoflota.colores  (id_color, nombre_color) values ('02','Blanco');
insert into modeladoflota.colores  (id_color, nombre_color) values ('03','Azul');
insert into modeladoflota.colores  (id_color, nombre_color) values ('04','Rojo');

-- Creamos la tabla de monedas

create table modeladoflota.moneda(
	id_moneda varchar(20) not null, --PK, FK
	nombre_moneda varchar(200) not null
);

--PK
alter table modeladoflota.moneda
add constraint id_moneda_PK primary key (id_moneda);

-- Creamos la tabla del histórico de revisiones 

create table modeladoflota.hist_revisiones(
	id_coche varchar(20) not null, --PK, FK
	fecha_revision date not null default '4000-01-01', -- PK
	numero_kilometros varchar(10) not null,
	id_moneda varchar(20) not null, --FK
	importe varchar(20) not null,
	descripcion varchar(256) not null
);

-- PK

alter table modeladoflota.hist_revisiones
add constraint id_hist_revisiones_PK primary key (id_coche, fecha_revision);

-- FK

alter table modeladoflota.hist_revisiones
add constraint revisiones_moneda_FK foreign key (id_moneda)
references modeladoflota.moneda(id_moneda);


---  Creamos las aseguradoras

create table modeladoflota.aseguradoras(
	id_aseguradora varchar(20) not null, --PK, FK
	nombre_aseguradora varchar(100) not  null

);
--PK

alter table modeladoflota.aseguradoras
add constraint id_aseguradora_PK primary key (id_aseguradora);

--- Creamos el histórico de los seguros del coche

create table modeladoflota.hist_aseguradoras(
	id_coche varchar(20) not null, --PK, FK
	fecha_comienzo date not null default '4000-01-01', -- PK
	fecha_fin date not null default '4000-01-01',
	id_aseguradora varchar(20) not null, --FK
	numero_poliza varchar(100) not null
);

-- PK

alter table modeladoflota.hist_aseguradoras
add constraint id_hist_aseguradoras_PK primary key (id_coche, fecha_comienzo);

-- FK

alter table modeladoflota.hist_aseguradoras 
add constraint hist_aseguradoras_nombre_FK foreign key (id_aseguradora)
references modeladoflota.aseguradoras(id_aseguradora);



-- Cargamos los datos de las moneda

insert into modeladoflota.moneda (id_moneda,nombre_moneda) values ('01', 'EURO');
insert into modeladoflota.moneda (id_moneda,nombre_moneda) values ('02', 'DÓLAR AMERICANO');

-- Cargamos los datos de las aseguradoras

insert into modeladoflota.aseguradoras (id_aseguradora, nombre_aseguradora) values ('01', 'MUTUA MADRILEÑA');
insert into modeladoflota.aseguradoras (id_aseguradora, nombre_aseguradora) values ('02', 'MAPFRE');
insert into modeladoflota.aseguradoras (id_aseguradora, nombre_aseguradora) values ('03', 'GÉNESIS');
insert into modeladoflota.aseguradoras (id_aseguradora, nombre_aseguradora) values ('04', 'PELAYO');

--- Cargamos los datos de los históricos de las revisiones

insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('01', '2022-10-15', '20000', '01', '200', 'Cambio ruedas');
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('02', '2022-11-20', '25000', '01', '100', 'Cambio aceite');
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('03', '2022-12-22', '20000', '01', '300', 'Revision Pre ITV');
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('04', '2023-01-15', '16500', '01', '400', 'Cambio ruedas y filtros');
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('05', '2023-01-16', '21456', '01', '225', 'Cambio aceite y filtros');
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('06', '2023-01-17', '40000', '01', '250', 'Limpieza inyectores');
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('07', '2022-08-13', '27513', '01', '1550', 'Cambio compresor');
---
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('08', '2022-08-13', '17262', '01', '200', 'Cambio ruedas');
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('09', '2022-08-13', '12463', '01', '1550', 'Cambio compresor');
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('10', '2022-08-13', '16283', '01', '300', 'Revision Pre ITV');
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('11', '2022-08-13', '23678', '01', '1550', 'Cambio compresor');
insert into modeladoflota.hist_revisiones (id_coche, fecha_revision,numero_kilometros,id_moneda,importe,descripcion) values ('12', '2022-08-13', '22200', '01', '1550', 'Cambio compresor');




-- Cargamos los datos del histórico de los seguros

insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('01','2022-07-21', '4000-01-01', '01', '0011223344');
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('02','2022-08-22', '4000-01-01', '02', '0093736544');
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('03','2022-09-23', '4000-01-01', '04', '0011263484');
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('04','2022-10-24', '4000-01-01', '03', '0827346558');
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('05','2022-11-21', '4000-01-01', '01', '1638590684');
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('06','2022-12-19', '4000-01-01', '02', '9735253784');
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('07','2020-08-07', '2023-01-01', '01', '8353474837');
---
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('08','2021-09-07', '4000-01-01', '03', '38W2626290');
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('09','2022-10-03', '2023-01-30', '04', '02UDH38392');
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('10','2023-11-05', '4000-01-01', '02', '02DHJE3939');
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('11','2021-12-28', '2023-02-01', '04', '7282B3U383');
insert into modeladoflota.hist_aseguradoras (id_coche,fecha_comienzo, fecha_fin,id_aseguradora,numero_poliza) values ('12','2020-03-30', '2023-02-04', '03', '29273B3839');



--- Creamos la tabla de coches de la flota

create table modeladoflota.coches(
	id_coche varchar(20) not null, --PK, FK
	id_modelo varchar(20) not null, --FK
	matricula varchar(20) not null,
	kilometros varchar(10) not null,
	id_color varchar(20) not null, --FK
	fecha_compra date not null,
	fecha_baja date not null default '4000-01-01'
	
);

-- PK

alter table modeladoflota.coches
add constraint id_coche_PK primary key (id_coche);

-- FK

alter table modeladoflota.coches
add constraint coches_modelos_FK foreign key (id_modelo)
references modeladoflota.modelos(id_modelo);

alter table modeladoflota.coches 
add constraint coches_colores_FK foreign key (id_color)
references modeladoflota.colores(id_color);

-- Cargamos los coches que hay en la flota de Keepcoding

insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('01','03','3023-KLM','53623','01','2021-06-23','4000-01-01');
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('02','10','1234-LVD','34212','03','2021-05-05','4000-01-01');
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('03','20','3456-LLL','45678','02','2022-02-15','4000-01-01');
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('04','15','1256-JGD','65234','04','2022-07-21','4000-01-01');
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('05','25','9876-JJY','79173','01','2022-01-06','4000-01-01');
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('06','09','4567-LCG','51936','02','2022-08-30','4000-01-01');
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('07','20','1378-MYJ','43567','04','2019-06-23','2023-01-13');
---
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('08','24','1302-MAA','23451','01','2019-03-09','4000-01-01');
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('09','25','1249-FSC','21562','02','2020-05-11','2023-01-07');
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('10','28','0770-LHS','19624','04','2021-07-16','4000-01-01');
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('11','30','1462-MXZ','17249','03','2022-09-20','2023-02-04');
insert into modeladoflota.coches (id_coche,id_modelo,matricula,kilometros,id_color,fecha_compra,fecha_baja) values ('12','32','9524-LSC','27854','02','2022-10-17','2023-01-27');
---


alter table modeladoflota.hist_revisiones
add constraint revisiones_coches_FK foreign key (id_coche)
references modeladoflota.coches(id_coche);

alter table modeladoflota.hist_aseguradoras 
add constraint hist_aseguradoras_coches_FK foreign key (id_coche)
references modeladoflota.coches(id_coche);












